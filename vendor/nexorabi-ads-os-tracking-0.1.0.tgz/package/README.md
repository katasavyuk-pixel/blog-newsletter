# @nexorabi/ads-os-tracking

Consentimiento, captura de atribución y envío deduplicado de eventos a Meta.

Tres entradas: el core no necesita React, el banner sí, y los eventos de backend
corren en Node.

```bash
npm i @nexorabi/ads-os-tracking
```

## La pieza que no se puede tocar

Meta deduplica emparejando **`event_id` Y `event_name`**, en una ventana de 48 h.
Si el píxel dispara `Compra` y el servidor manda `Purchase`, **no dedupea nunca**:
cada conversión cuenta doble, la optimización se envenena, y el doble conteo se
lee como buen rendimiento durante semanas sin que aparezca ningún error.

De ahí que `track()` reciba el **nombre de evento de Meta**, no un alias interno.

## Consentimiento

Nada de Meta se carga ni se dispara antes del consentimiento explícito: sin él el
script no se inyecta, `window.fbq` no existe y no sale ninguna petición a
`connect.facebook.net`. Es una comprobación literal en la pestaña Network.

```tsx
import { ConsentProvider, ConsentBanner } from "@nexorabi/ads-os-tracking/react";

<ConsentProvider
  config={{
    pixelId: process.env.NEXT_PUBLIC_META_PIXEL_ID!,
    collectorUrl: process.env.NEXT_PUBLIC_ADS_OS_COLLECTOR_URL!,
    apiKey: process.env.NEXT_PUBLIC_ADS_OS_API_KEY!,
  }}
>
  {children}
  <ConsentBanner policyHref="/politica-de-cookies" />
</ConsentProvider>
```

Si ya tienes tu propio banner, quédate con él y puentea el estado con
`setConsent({ marketing })`. `ConsentProvider` solo arranca el tracking.

## Eventos

```ts
import { track, identify, getAttribution } from "@nexorabi/ads-os-tracking";

// Síncrona, devuelve el eventID y NUNCA lanza.
const eventId = track("Purchase", { value: 49.9, currency: "EUR" });

// Con datos personales: se hashean en el colector, nunca en el navegador.
track("Lead", {}, { user: { email: form.email } });

// Al registrar a alguien, con TU id de usuario.
identify(usuario.id, { email: usuario.email, origenDeclarado: respuesta });
```

Si el colector está caído el píxel sigue solo; si un bloqueador tumba el píxel el
colector sigue solo.

## Backend

```ts
import { trackServer } from "@nexorabi/ads-os-tracking/server";

// En el webhook de cobro. Mismo eventId que devolvió track() para deduplicar.
await trackServer({
  event: "Purchase",
  eventId: idGuardadoAlIniciarElPago,
  user: { email, ip: ipDelUsuario, userAgent: uaDelUsuario },
  custom: { value: 49.9, currency: "EUR" },
});
```

Lee `ADS_OS_COLLECTOR_URL` y `ADS_OS_API_KEY` del entorno si no le pasas config.

## "¿Cómo nos conociste?"

```tsx
import { OriginQuestion } from "@nexorabi/ads-os-tracking/react";

<OriginQuestion value={origen} onChange={setOrigen} />
```

Campo de **texto abierto**, y nunca debe ser un desplegable: un desplegable elige
las respuestas por el usuario y solo te devuelve las categorías que ya te habías
imaginado. El valor está justo en lo que la gente escribe y tú no habrías puesto
en una lista.

## Superficie pública

| Entrada | Qué trae |
|---|---|
| `@nexorabi/ads-os-tracking` | `track`, `identify`, `initTracking`, `getAttribution`, `getConsent`, `setConsent`, `resetConsent`, `hasMarketingConsent`, `onConsentChange`, `getFbp`, `getFbc` |
| `@nexorabi/ads-os-tracking/react` | `ConsentProvider`, `ConsentBanner`, `OriginQuestion`, `useConsent` |
| `@nexorabi/ads-os-tracking/server` | `trackServer` |

MIT.
